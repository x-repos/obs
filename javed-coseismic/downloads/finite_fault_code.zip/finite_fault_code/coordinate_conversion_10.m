function [L]=coordinate_conversion_10(x1,y1,z1,m,n)
x=reshape(x1,m,n);
x=x';
x=reshape(x,m*n,1);
y=reshape(y1,m,n);
y=y';
y=reshape(y,m*n,1);
z=reshape(z1,m,n);
z=z';
z=reshape(z,m*n,1);


L=[x y z ];

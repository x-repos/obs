function [ version, versiondate, wholast ] = GTdef_version()
version = '4.0.3';
versiondate = ['Friday, May 21, 2021 10:19 AM'];
wholast='anewman';

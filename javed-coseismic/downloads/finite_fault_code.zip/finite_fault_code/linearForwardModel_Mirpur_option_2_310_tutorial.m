
% unicycle functions
clear all;
import unicycle.*
minmax=@(x)[min(x(:)) max(x(:))];

L=cell(1,1);
H=cell(1,1);
insar=cell(1,1);

  load ./insar/S1_uniform_F2_sampling_final.dat
  S1_uniform_F2_S_final=S1_uniform_F2_sampling_final;
  insar{1}.xy=S1_uniform_F2_S_final(:,9:10)*1e3;
  insar{1}.Dlos=S1_uniform_F2_S_final(:,3)*1e-3;
  insar{1}.los=S1_uniform_F2_S_final(:,4:6);
 % insar{1}.DSArea=S1_uniform_F2_S_final(:,9);

Ns=20;
Nd=20;
E=30e9;
nu=0.25;
lambda=(2*E*nu)/(1-2*nu);

%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%                      F A U L T : P A T C H E S
%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

clear megathrust;

% Fault dimension
bestLength=30;
bestDepth=10;
bestWidth=30;
bestSlipDS=-1.0;
bestSlipSS=-1.0;

% Fault 1


% megathrust{1}.alpha=317.52240875936684;
 megathrust{1}.alpha=310;
 megathrust{1}.delta=6;
 %megathrust{1}.delta=7.772302481517313;
 megathrust{1}.rake=100;

% megathrust{1}.x0=[-2.474488562490890;-17.641724633238322;-4.4];
megathrust{1}.x0=[-0.979486334016744;-29.950473109446360;-3.4];
megathrust{1}.nPatchX=20;
megathrust{1}.nPatchY=20;
megathrust{1}.dgf=2;
megathrust{1}.patchLength=1*bestLength/megathrust{1}.nPatchX; % Along Strike length of each Patch
megathrust{1}.patchWidth=bestWidth/megathrust{1}.nPatchY;
megathrust{1}.patchX=repmat((0:(megathrust{1}.nPatchX-1))'*megathrust{1}.patchLength,1,megathrust{1}.nPatchY);
megathrust{1}.patchY=repmat((0:(megathrust{1}.nPatchY-1))*megathrust{1}.patchWidth,megathrust{1}.nPatchX,1);
megathrust{1}.patchZ=0*megathrust{1}.patchX;

megathrust{1}.normalVector=[sind(megathrust{1}.delta)*cosd(megathrust{1}.alpha), -sind(megathrust{1}.alpha).*sind(megathrust{1}.delta), cosd(megathrust{1}.delta)];
megathrust{1}.strikeVector=[sind(megathrust{1}.alpha), cosd(megathrust{1}.alpha), 0*sind(megathrust{1}.delta)];
megathrust{1}.dipVector=[cosd(megathrust{1}.delta)*cosd(megathrust{1}.alpha), -cosd(megathrust{1}.delta)*sind(megathrust{1}.alpha), -sind(megathrust{1}.delta)];
% top Left Corner
for i=1:length(megathrust)
    megathrust{i}.x=zeros(numel(megathrust{i}.patchX),3);
    megathrust{i}.x(:,1)=megathrust{i}.x0(1)+megathrust{i}.patchX(:).*megathrust{i}.strikeVector(:,1)+megathrust{i}.patchY(:).*megathrust{i}.dipVector(:,1)+megathrust{i}.patchZ(:).*megathrust{i}.normalVector(:,1);
    megathrust{i}.x(:,2)=megathrust{i}.x0(2)+megathrust{i}.patchX(:).*megathrust{i}.strikeVector(:,2)+megathrust{i}.patchY(:).*megathrust{i}.dipVector(:,2)+megathrust{i}.patchZ(:).*megathrust{i}.normalVector(:,2);
    megathrust{i}.x(:,3)=megathrust{i}.x0(3)+megathrust{i}.patchX(:).*megathrust{i}.strikeVector(:,3)+megathrust{i}.patchY(:).*megathrust{i}.dipVector(:,3)+megathrust{i}.patchZ(:).*megathrust{i}.normalVector(:,3);
    
    % top Right Corner
    Fault{i}.X2=megathrust{i}.x(:,1)+megathrust{i}.patchLength*megathrust{i}.strikeVector(:,1);
    Fault{i}.Y2=megathrust{i}.x(:,2)+megathrust{i}.patchLength*megathrust{i}.strikeVector(:,2);
    Fault{i}.Z2=megathrust{i}.x(:,3)+megathrust{i}.patchLength*megathrust{i}.strikeVector(:,3);
    
    % Bottom Right Corner
    Fault{i}.X3=Fault{i}.X2+megathrust{i}.patchWidth*megathrust{i}.dipVector(:,1);
    Fault{i}.Y3=Fault{i}.Y2+megathrust{i}.patchWidth*megathrust{i}.dipVector(:,2);
    Fault{i}.Z3=Fault{i}.Z2+megathrust{i}.patchWidth*megathrust{i}.dipVector(:,3);
    
    % Bottom Left Corner
    Fault{i}.X4=Fault{i}.X3-megathrust{i}.patchLength*megathrust{i}.strikeVector(:,1);
    Fault{i}.Y4=Fault{i}.Y3-megathrust{i}.patchLength*megathrust{i}.strikeVector(:,2);
    Fault{i}.Z4=Fault{i}.Z3-megathrust{i}.patchLength*megathrust{i}.strikeVector(:,3);
    
    megathrust{i}.patch.x=[megathrust{i}.x(:,1) Fault{i}.X2(:) Fault{i}.X3(:) Fault{i}.X4(:)]';
    megathrust{i}.patch.y=[megathrust{i}.x(:,2) Fault{i}.Y2(:) Fault{i}.Y3(:) Fault{i}.Y4(:)]';
    megathrust{i}.patch.z=[megathrust{i}.x(:,3) Fault{i}.Z2(:) Fault{i}.Z3(:) Fault{i}.Z4(:)]';
    
    megathrust{i}.xc(:,1)=(megathrust{i}.x(:,1)+Fault{i}.X2+Fault{i}.X3+Fault{i}.X4)/4;
    megathrust{i}.xc(:,2)=(megathrust{i}.x(:,2)+Fault{i}.Y2+Fault{i}.Y3+Fault{i}.Y4)/4;
   megathrust{i}.xc(:,3)=(megathrust{i}.x(:,3)+Fault{i}.Z2+Fault{i}.Z3+Fault{i}.Z4)/4;
end


%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%                 C H E C K   F A U L T   G E O M E T R Y
%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

figure(1);clf;
set(gcf,'Name','Fault geometry');
hold on
patch(megathrust{1}.patch.x,megathrust{1}.patch.y,-megathrust{1}.patch.z,0*megathrust{1}.patch.x,'FaceColor','None')
xlabel('East (km)')
ylabel('North (km)')
zlabel('Depth (km)')
axis equal tight
zlim=get(gca,'zlim');
set(gca,'zlim',[0 zlim(2)]);
set(gca,'ZDir','Reverse');
set(gca,'view',[24.8000   24.4000]);
box on

%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%                    E X P O R T   T O   . F L T 
%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
flt.id=[1:length(megathrust{1}.x(:,3))]';
flt.x=1e3.*[megathrust{1}.x(:,2)];
flt.y=1e3*[megathrust{1}.x(:,1)];
flt.z=-1e3*[megathrust{1}.x(:,3)];
[L]=coordinate_conversion_10(flt.x,flt.y,flt.z,Ns,Nd);

flt.x=L(:,1);
flt.y=L(:,2);
flt.z=L(:,3);
flt.strike=[megathrust{1}.alpha*ones(length(megathrust{1}.x(:,3)),1)];
flt.dip=[megathrust{1}.delta*ones(length(megathrust{1}.x(:,3)),1)];
flt.rake=[megathrust{1}.rake*ones(length(megathrust{1}.x(:,3)),1)];
[L]=coordinate_conversion_10(flt.strike,flt.dip,flt.rake,Ns,Nd);
flt.strike=L(:,1);
flt.dip=L(:,2);
flt.rake=L(:,3);
flt.dx=[megathrust{1}.patchLength*ones(length(megathrust{1}.x(:,3)),1)]*1e3;
flt.dy=[megathrust{1}.patchWidth*ones(length(megathrust{1}.x(:,3)),1)]*1e3;
[L]=coordinate_conversion_10(flt.x,flt.dx,flt.dy,Ns,Nd);
flt.dx=L(:,2);
flt.dy=L(:,3);
fid=fopen('./faults/mirpur.flt','wt');
fprintf(fid,'%i %f %f %f %f %f %f %f %f\n',[flt.id,flt.x,flt.y,flt.z,flt.dx,flt.dy,flt.strike,flt.dip,flt.rake]');
fclose(fid);
%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%                           L O A D   F A U L T
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %

rcv=unicycle.geometry.rectangleReceiver('./faults/mirpur.flt',unicycle.greens.okada92(30e3,nu));

figure(21);clf;
set(gcf,'Name','Fault geometry');
hold on
rcv.plotPatch();
xlabel('East (m)')
ylabel('North (m)')
zlabel('Elevation (m)')
axis equal tight
set(gca,'View',[24.8000   24.4000]);
box on


%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%           C O M P U T E   G R E E N S   F U N C T I O N
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %

for k=1:length(insar)
    fprintf('# computing Greens function %d/%d\n',k,length(insar));
    for j=1:length(rcv.x)
        XDisp = insar{k}.xy(:,1) - rcv.x(j,1);
        YDisp = insar{k}.xy(:,2) - rcv.x(j,2);
        depth = -1*rcv.x(j,3);
        
        [uxP,uyP,uzP] = unicycle.greens.computeDisplacementOkada85( ...
            1,XDisp,YDisp, ...
            nu,rcv.dip(j)/180*pi,depth, ...
            rcv.L(j),rcv.W(j), ...
            1,rcv.strike(j)/180*pi);
        insar{k}.Gss(:,j) = uxP(:).*insar{k}.los(:,1) + uyP(:).*insar{k}.los(:,2) + uzP(:).*insar{k}.los(:,3);
        
        [uxd,uyd,uzd] = unicycle.greens.computeDisplacementOkada85( ...
            1,XDisp,YDisp, ...
            nu,rcv.dip(j)/180*pi,depth, ...
            rcv.L(j),rcv.W(j), ...
            2,rcv.strike(j)/180*pi);
        insar{k}.Gds(:,j) =uxd(:).*insar{k}.los(:,1) + uyd(:).*insar{k}.los(:,2) + uzd(:).*insar{k}.los(:,3);
        
        insar{k}.GRamp=[ones(length(insar{k}.Dlos),1),insar{k}.xy(:,1),insar{k}.xy(:,2)];
        
    end
end

% to reshape G for the inversion process[Gss,0;0,Gds] 
 for i=1:length(insar)
     if i==1
         Ginsar=[insar{i}.Gss,insar{i}.Gds, ...
         zeros(length(insar{i}.Dlos),3*(i-1)), insar{i}.GRamp, zeros(length(insar{i}.Dlos),3*(length(insar)-i))];
         d=[insar{i}.Dlos];
     else
         Ginsar=[Ginsar;[insar{i}.Gss,insar{i}.Gds, ...
         zeros(length(insar{i}.Dlos),3*(i-1)), insar{i}.GRamp, zeros(length(insar{i}.Dlos),3*(length(insar)-i))]];
         d=[d;insar{i}.Dlos];
      
     end
 end
 
G=Ginsar;
dd=1500;
ds=1500;
Nd=20;
Ns=20;
%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%                     S M O O T H I N G   M A T R I X
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %
[sm_1d3pf,sm_1d3pb,sm_2d,sm_abs] = GTdef_sm_fixed_2slips(dd,ds,Nd,Ns);

sm=full(sm_2d);
sm_final=[sm,zeros(size(sm,1),length(insar)*3)];
%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%   L E A S T - S Q U A R E S   I N V E R S I O N ,   S M O O T H I N G
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

%              I N V E R S I O N   W I T H   L S Q L I N

% % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %
k=[0 0.04 0.06 0.08 0.1 0.15 0.2 0.4 0.8 1.6 5 10 20 30 40 50 60 70 80 90 100 120 140 150 170 180 190 200 210 220 230 240 250 260 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000];
%k=500;
beta=k.^2;
rake=100.0;
% 
 rcv.rake=rake*ones(rcv.N,1);
A14=[diag(cosd(rcv.rake)),diag(sind(rcv.rake)),zeros(length(rcv.rake),3*length(insar)); ...
     diag(cosd(rcv.rake+70)),diag(sind(rcv.rake+70)),zeros(length(rcv.rake),3*length(insar)); ...
     diag(cosd(rcv.rake-70)),diag(sind(rcv.rake-70)),zeros(length(rcv.rake),3*length(insar))];
beq14=zeros(size(A14,1),1);
D=[diag(cosd(rcv.rake+90)),diag(sind(rcv.rake+90)),zeros(length(rcv.rake),3*length(insar))];
options=optimset('TolFun',1e-12,'MaxIter',2000);
tic

for ii=1:length(beta)

sm=sm_final.*beta(1,ii);
d_sm = zeros(size(sm,1),1);
Identity=0.01*eye(size(sm));

 G1=[G;sm;Identity];
 d1=[d;d_sm;d_sm];

 m14=lsqlin(G1,d1,-A14,beq14,[],[],[],[],[],options);

toc
disp('m14 done');
 

%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%            F I G U R E :   I N V E R S I O N   R E S U L T S
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %


m=m14;

mss=m(1:rcv.N);
mds=m(rcv.N+1:2*rcv.N);

mfinal=sqrt(mss.^2+mds.^2);

figure(17);clf;hold on

rcv.plotPatch(mfinal);
rcv.plotSlipVectors(mss,mds,500)
rake_final=atan(mds./mss);
xlabel('East (m)')
ylabel('North (m)')
h=colorbar('location','South');
ylabel(h,'slip[mm]');
axis equal
caxis([0, 0.5])
hot2 = hot;
        hot2(1:5,:) = [];      % chopping off start of colorbar to get rid of black - i want the maximum colour to be dark red  
        hot2 = [hot2; ones(5,3)];  % adding more white to the bottom
        colormap(hot2)
        colormap(flipud(colormap))
box on
set(gca,'view',[300,25]);
% xlim([-11000 12000])
% ylim([-19000 12000])
%  zlim([-8000 -4000])
axis equal


%% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%
%             D A T A ,   M O D E L ,   &   R E S I D U A L S
%
% % % % % % % % % % % % % % % % % % %% % % % % % % % % % % % % % % % % % %
cmap.Seismo = colormap_cpt('GMT_seis.cpt', 100);
% 
figure(170);clf;set(gcf,'name','Data, model, residuals')
for k=1:length(insar)
     if(k==1)
%           insar{k}.Dlos=insar{k}.Dlos+0.05;
%            insar{k}.model=insar{k}.model+0.05;
     end 
    subplot(length(insar),3,3*(k-1)+1);cla;hold on
    scatter(insar{k}.xy(:,1),insar{k}.xy(:,2),[],insar{k}.Dlos,'+');
    rcv.plotPatch();
    if k==length(insar)
        xlabel('x (km)');
        ylabel('y (km)');
    end
    colorbar
    caxis([-0.06 0.06]);
    axis equal
    title('Data')
    box on
    insar{k}.model=[insar{k}.Gss,insar{k}.Gds,zeros(length(insar{k}.Dlos),3*(k-1)),insar{k}.GRamp,zeros(length(insar{k}.Dlos),3*(length(insar)-k))]*m;
    
      if(k==1)
%          insar{k}.Dlos=insar{k}.Dlos+0.05;
%           insar{k}.model=insar{k}.model+0.05;
     end 
    subplot(length(insar),3,3*(k-1)+2);cla;hold on
    scatter(insar{k}.xy(:,1),insar{k}.xy(:,2),[],insar{k}.model,'+');
    rcv.plotPatch();
    title('Model prediction')
    if k==length(insar)
        xlabel('East (km)');
        ylabel('North (km)');
    end
    colorbar
   caxis([-0.06 0.06]);
    axis equal
    box on
     
    subplot(length(insar),3,3*(k-1)+3);cla;hold on
    r=insar{k}.Dlos-insar{k}.model;
    vr=1-(r'*r)/(insar{k}.Dlos'*insar{k}.Dlos);
    RMS=sqrt(sum(r.^2)/length(r))
     scatter(insar{k}.xy(:,1),insar{k}.xy(:,2),[],r,'+');       
    rcv.plotPatch();
    if k==length(insar)
        xlabel('East (km)');
        ylabel('North (km)');
    end
    colorbar
    caxis([-0.06 0.06]);
    title(sprintf('Residuals VR=%5.2f%%',vr*100));
    axis equal
    box on
end

total=length(mss)+length(mds);
data_num = 0; 
rss = 0; 
wrss = 0; chi2 = 0;
wrms = 0; rchi2 = 0;
Xmod = G1*m14; 
data_ind = find(~isnan(d));	
data_num = data_num+length(data_ind);
pnt_dif2 = (Xmod(data_ind)-d(data_ind)).^2;
rss = rss+sum(pnt_dif2);
sm_all = sum(abs(sm_final*m14));
sm_num = size(sm,1);
r_2d(ii,1) = 1e8*0.5*sm_all/sm_num;
rms(ii,1) = sqrt(rss/data_num);
end

% scaling_factor=0.5;
% [rake,netslip]=comp2rake(mss,mds);

% rake_final=reshape(rake,Nd,Ns);
% mfinal=reshape(netslip,Nd,Ns);
% %rake_final=rake_final';
% rake1=reshape(rake_final,Ns*Nd,1);
% netslip1=reshape(mfinal,Ns*Nd,1);
% k=1;
% order=ones(Ns,Nd);
% 
% spatial_model=megathrust{1}.patchLength*ones(Ns,Nd);
%  for ii=1:20
%     for jj=1:20
%         order(ii,jj)=k;
%         k=k+1;
%     end
% end
% k=1;
% l=1;
% for ii=1:20
%    
%     for jj=1:20
%         if jj==1
%            Order2(k,1)=20*l;
%            Order2(k,2)=k;
%            k=k+1;
%            
%            else
%            Order2(k,1)=(20*l)-(jj-1);
%            Order2(k,2)=k;
%            k=k+1;
%         end
%     end
%     l=l+1;
% end
% Order3=sortrows(Order2,-2);
% Order4=Order3(:,1);
% figure
% 
% imagesc([megathrust{1}.patchWidth/2, (sum(bestLength)-(megathrust{1}.patchLength/2))], [megathrust{1}.patchWidth/2, (bestWidth/sin(deg2rad(megathrust{1}.delta)))-megathrust{1}.patchWidth/2], reshape( flipud(mfinal(order)), megathrust{1}.nPatchY,[]) );
% imagesc([dd/2/1000, (sum(bestLength)-(megathrust{1}.patchLength/2))], [dd/2/1000, ((dd/1000)*Ns)-(dd/2/1000)], mfinal);
% hold on; 
% axis equal tight
% colorbar
% 
% [ x,y,u_arrow,v_arrow ] = prepare_plot_rake(rake1,netslip1,spatial_model,dd/1000,Nd,Ns );
% quiver(x.*1e3,y.*1e3,u_arrow,v_arrow, scaling_factor, 'k');
%                      
% xlabel('Along Strike (km)'); 
% ylabel('Down dip (km)'); 
% ylabel(colorbar, 'Slip (m)');
%         
% caxis([0  0.5])
% hot2 = hot;
%         hot2(1:5,:) = [];      % chopping off start of colorbar to get rid of black - i want the maximum colour to be dark red  
%         hot2 = [hot2; ones(5,3)];  % adding more white to the bottom
%         colormap(hot2)
%         colormap(flipud(colormap))
%         
% fid=fopen('./faults/Mirpur__slip.flt','wt');
% fprintf(fid,'%i %f %f %f %f %f %f %f %f %f\n',[flt.id,netslip,flt.x,flt.y,flt.z,flt.dx,flt.dy,flt.strike,flt.dip,rake]');
% fclose(fid);


